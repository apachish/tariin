#
#<?php die('Forbidden.'); ?>
#Date: 2014-10-09 19:45:42 UTC
#Software: Joomla Platform 12.2.0 Stable [ Neil Armstrong ] 21-September-2012 00:00 GMT

#Fields: datetime	priority	category	message
2014-10-09T19:45:42+00:00	INFO	joomlafailure	Username and password do not match or you do not have an account yet.
2014-10-09T19:47:00+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T19:59:11+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T20:08:16+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T20:15:44+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T20:28:00+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T20:28:06+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:12:44+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:13:25+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:13:32+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:13:53+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:18:26+00:00	INFO	joomlafailure	Username and password do not match or you do not have an account yet.
2014-10-09T21:24:16+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:50:18+00:00	INFO	joomlafailure	رمز عبور اشتباه
2014-10-09T21:55:29+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T21:57:04+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T22:00:30+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-09T22:00:50+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-10T08:41:26+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-10T08:53:56+00:00	INFO	joomlafailure	Username and password do not match or you do not have an account yet.
2014-10-17T05:15:16+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-17T20:03:09+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-17T20:52:02+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-17T21:26:16+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-18T17:17:00+00:00	INFO	joomlacanceled	
2014-10-18T17:17:14+00:00	INFO	joomlacanceled	
2014-10-18T17:17:21+00:00	INFO	joomlacanceled	
2014-10-21T20:24:18+00:00	INFO	joomlacanceled	
2014-10-22T20:32:29+00:00	INFO	joomlafailure	رمزعبور خالی مجاز نیست
2014-10-22T21:22:23+00:00	INFO	joomlafailure	رمزعبور خالی مجاز نیست
2014-10-24T10:07:22+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:08:07+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:08:36+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:57:35+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:57:36+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:57:36+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:57:36+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T10:57:42+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-24T11:00:51+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-24T11:00:57+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-24T11:01:10+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-10-24T11:18:43+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T11:19:47+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T11:23:04+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-10-24T21:34:27+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-11-02T03:38:12+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-11-02T03:38:21+00:00	INFO	joomlafailure	پسورد خالی اجازه داده نمی شود
2014-11-02T04:39:23+00:00	INFO	joomlafailure	رمزعبور خالی مجاز نیست
2014-11-07T16:22:05+00:00	INFO	joomlafailure	نام کاربری یا کلمه عبور صحیح نیستند و یا شما شناسه ای در سایت ندارید
2014-11-07T18:42:52+00:00	INFO	joomlafailure	کاربر موجود نیست
2014-11-07T19:48:01+00:00	INFO	joomlafailure	رمز عبور اشتباه
2014-11-07T19:48:09+00:00	INFO	joomlafailure	رمز عبور اشتباه
