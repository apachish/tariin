1- This Module support?
	* This module displays a username and password login form.
	* This Module kept all params of default login module.
	* Support 6 beauty themes, you can select one or multi for your website.
	* Support 2 type (Slidedown or Full): Select 'Slidedown' when you want show a button then hover or click to that login form will slidedown. * Select 'Full' when you want to show full form login.
	* Support 2 effects (hover or click): When you selected 'type' is 'Slidedown'.
	* Login label: You can change text for login label.
	* You can download and see demo of this module here: Brainymore.com
	
	* Brainymore! Official site: http://www.brainymore.com
	* Detailed changes in the Changelog: 
Copyright:
	* Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.
	* Distributed under the GNU General Public License version 2 or later
	* See Licenses details at LICENSE.txt
