<?php
/**
 *  @package     AkeebaStrapper
 *  @copyright   Copyright (c)2010-2014 Nicholas K. Dionysopoulos
 *  @license     GNU General Public License version 2, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('AKEEBASTRAPPER_VERSION', 'rev844F136-1410443902');
define('AKEEBASTRAPPER_DATE', '2014-09-11 16:58:22');
define('AKEEBASTRAPPER_MEDIATAG', md5(AKEEBASTRAPPER_VERSION . AKEEBASTRAPPER_DATE));