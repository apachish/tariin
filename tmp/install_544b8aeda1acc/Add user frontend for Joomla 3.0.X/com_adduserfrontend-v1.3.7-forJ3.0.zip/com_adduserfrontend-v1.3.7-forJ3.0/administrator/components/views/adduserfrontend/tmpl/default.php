<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('Add user Frontend'), 'generic.png');
JToolBarHelper::preferences('com_adduserfrontend');
?>
<!-- Deafult administrator message -->
Click on the Parameters button to edit your settings! 
