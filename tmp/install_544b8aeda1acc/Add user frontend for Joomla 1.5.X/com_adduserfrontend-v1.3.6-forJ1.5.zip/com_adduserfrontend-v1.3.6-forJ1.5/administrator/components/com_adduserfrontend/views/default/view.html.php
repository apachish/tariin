<?php

/**

 * Joomla! 1.5 component Add user Frontend

 *

 * @version $Id: view.html.php 2010-08-24 10:48:13 svn $

 * @author Kim Pittoors

 * @package Joomla

 * @subpackage Add user Frontend

 * @license GNU/GPL

 *

 * Add users to Community builder on the frontend

 *

* @Copyright Copyright (C) 2010 - Kim Pittoors
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html 


 *

 */



// no direct access

defined('_JEXEC') or die('Restricted access');



// Import Joomla! libraries

jimport( 'joomla.application.component.view');

class AdduserfrontendViewDefault extends JView {

    function display($tpl = null) {

        parent::display($tpl);

    }

}

?>