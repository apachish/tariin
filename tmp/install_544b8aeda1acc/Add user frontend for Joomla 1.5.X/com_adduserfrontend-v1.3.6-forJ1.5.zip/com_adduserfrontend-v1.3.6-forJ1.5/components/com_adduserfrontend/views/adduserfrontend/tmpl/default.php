<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php
/*
* @Copyright Copyright (C) 2012 - Kim Pittoors
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html 
*/

// Get joomla component system params //
$itemid = JRequest::getInt('Itemid', 0); 
$params = &JComponentHelper::getParams( 'com_adduserfrontend' );
$operationmode = $params->get( 'operationmode', 0);
$namemode = $params->get( 'namemode', 0);  
$setusertype = $params->get( 'setusertype');  
$notificationemail = $params->get( 'notificationemail', 0);
$adminnotificationemail = $params->get( 'adminnotificationemail', 0);
$usernamemode = $params->get( 'usernamemode', 0);

 // Check if the group is chosen from frontend or backend
$usertypemode = $params->get( 'usertypemode', 0); 	
if($usertypemode == '0'){
$setusertype = $params->get( 'setusertype', 18); 
} else {
$setusertype = "FRONTEND";
}
// END - Check if the group is chosen from frontend or backend

if($usernamemode !== '1'){
$unameexist = '0';
} else {
$unameexist = $params->get( 'unameexist', 0);
}
  
$emailexist = $params->get( 'emailexist', 1);
$passwordmode = $params->get( 'passwordmode', 0);
$genericemail = $params->get( 'genericemail', 0);
  
  
// DB establish
$jconfig = new JConfig();
$db_error = "Mysql error!";
$db_config = mysql_connect( $jconfig->host, $jconfig->user, $jconfig->password ) or die( $db_error );
mysql_select_db( $jconfig->db, $db_config ) or die( $db_error );  
  
// Get Joomla DB prefix
$config =& JFactory::getConfig();
$table_prefix = $config->getValue( 'dbprefix' );

// Clean special chars
function clean_now($text)
{
$text=strtolower($text);
$code_entities_match = array(' ','--','&quot;','!','@','#','$','%','^','&','*','(',')','_','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','/','*','+','~','`','=');  
$code_entities_replace = array('-','-','','','','','','','','','','','','','','','','','','','','','','','');
$text = str_replace($code_entities_match, $code_entities_replace, $text);
return $text;
} 
// End special chars

// Function to create a random password
function createRandomPassword() {
$chars = "abcdefghijkmnopqrstuvwxyz023456789";
srand((double)microtime()*1000000);
$i = 0;
$pass = '' ;
while ($i <= 7) {
$num = rand() % 33;
$tmp = substr($chars, $num, 1);
$pass = $pass . $tmp;
		
 $i++;
 
    }
	
    return $pass;
}
// End - Function to create a random password

// Get joomla user //
$user =& JFactory::getUser();
$groupid = $user->get('gid');

// Handle form
if(isset($_POST['import'])) {
	
if($passwordmode == 0){
$createpassword = createRandomPassword();
$password = md5($createpassword);
$showpass = $createpassword;
} else {	
$postpassword  = trim($_POST['password']);
$password = md5($postpassword);
$showpass = $postpassword;
}
// Getting name from form
if($namemode == 1){
$firstname = trim($_POST['firstname']);
$lastname = trim($_POST['lastname']);
} else {
$name = trim($_POST['name']);

// Get firstname and lastname
$xname = explode(" ", $name);
$firstname = $xname[0];

// Make lastname
if(!empty($xname[1])) {	
$lastname = $xname[1];	
}
if(!empty($xname[2])) {	
$lastname = $xname[1].' '.$xname[2];	
}
if(!empty($xname[3])) {	
$lastname = $xname[1].' '.$xname[2].' '.$xname[3];	
}
if(!empty($xname[4])) {	
$lastname = $xname[1].' '.$xname[2].' '.$xname[3].' '.$xname[4];	
}
if(!empty($xname[5])) {	
$lastname = $xname[1].' '.$xname[2].' '.$xname[3].' '.$xname[4].' '.$xname[5];	
}
if(!empty($xname[6])) {	
$lastname = $xname[1].' '.$xname[2].' '.$xname[3].' '.$xname[4].' '.$xname[5].' '.$xname[6];	
}
	
}
$divider = ' ';
$name = $firstname.$divider.$lastname; // Complete name


// Loading group ID (if chosen from frontend)
$group = $_POST['group'];

// Getting the username from the form or creating one based on the name
if($usernamemode == 1){
$username  = trim($_POST['username']);
$username = clean_now($username);
$username1 = $username;
} elseif ($usernamemode == 2) {
$username = trim($_POST['email']);
$username1 = $username;
} else {
if(empty($lastname)) { 
$username1 = $firstname; 
} else {
$lastnamesign = mb_substr ($lastname, 0, 1);
$username1 = $firstname . '-' . $lastnamesign;
}
$username1 = str_replace (" ", "-", $username1);
$username1 = strtolower($username1); 
$username = $username1;
}

// Make addition to username if username exists
function MakeAddition($fusername) {
	
// Get DB acces
$db =& JFactory::getDBO();

// Going into a loop
$finished = false;  // We're not finished loop yet (we just started the loop)
$i = 1; // Counting
while(!$finished) {                          // while not finished
$sql = "SELECT COUNT(*) ".$db->nameQuote('username')." FROM ".$db->nameQuote('#__users')." WHERE ".$db->nameQuote('username')." = ".$db->quote($fusername.$i).""; // Check in DB if the alternative username doesnt exist
$db->setQuery($sql);
$num_rows_add = $db->loadResult();	    
if ($num_rows_add == "0") {        // If username DOES NOT exist...
$finished = true;                  // We are finished stop loop
} 
$i++;
}
return $i-1;
}
// We have found a free alternative username lets add it to the $addition string
$addition = MakeAddition($username); 
// End - Make addition to username if username exists

// Check if the usertype ID that is provided in the settings is an existing usergroup  
if($setusertype == "FRONTEND"){
$usertype = $group;
$db =& JFactory::getDBO();
$query = "SELECT ".$db->nameQuote('name')." FROM #__core_acl_aro_groups WHERE id = ".$db->quote($usertype)."";	
$debugq = $query;
$db->setQuery($query);
$usertypename = $db->loadResult();
if($usertypename == ""){
echo '<p><font color="red">The group-<b>ID</b> you provided in your settings doesnt exist in the #__usergroups table! Fix this in your settings.</font></p>';							
}
}
// END - Check if the usertype ID that is provided in the settings is an existing usergroup  

// Get usertype from config
if($setusertype == "18"){
$usertype = '18'; 
$usertypename = 'Registered';
}
if($setusertype == "19"){
$usertype = '19'; 
$usertypename = 'Author';
}
if($setusertype == "20"){
$usertype = '20'; 
$usertypename = 'Editor';
}
if($setusertype == "21"){
$usertype = '21'; 
$usertypename = 'Publisher';
}
if($setusertype == "23"){
$usertype = '23'; 
$usertypename = 'Manager';
}
if($setusertype == "24"){
$usertype = '24'; 
$usertypename = 'Administrator';
}
// End get usertype from config //

// Some other data
$block = '0';
$sendmail = '0';

// Check if username exists //
$sql = mysql_query("SELECT username FROM " . $table_prefix . "users WHERE username='" . $username . "'");
$num_rows = mysql_num_rows($sql);
if($num_rows == 0){
$username = $username;
 } else {
if ($unameexist == "0") {
$username = $username.$addition;
$usernameline = "" . JText::_('THEUSERNAME') . " <strong>" . $username1 . "</strong> " . JText::_('USERCHANGENAME') . " <strong>" . $username . "</strong><br>";
echo $usernameline;
$usernameexists = "0";
} else {	
$usernameexists = "1";	
}
}	
if( $genericemail == "1" ) {
	
// Get Domain
$domain = $_SERVER['HTTP_HOST']; 
$domain = str_replace ("www.", "", $domain);

// Make generic email
$email = $username . '@' . $domain;
} else {
$email = trim($_POST['email']);
}

// Check if email exists //
$sql = mysql_query("SELECT email FROM " . $table_prefix . "users WHERE email='" . $email . "'");
$num_rows = mysql_num_rows($sql);
if($num_rows == 0){
$email = $email;
} else {	 
if ($emailexist == "1") {	 
$emaildoesexist = "1"; // This email already exists in the joomla user db
}
}	
if($usernameexists == "1" || $emaildoesexist == "1") { // Remember input fields
setcookie("name", $name, time()+30); 
setcookie("firstname", $firstname, time()+30); 
setcookie("lastname", $lastname, time()+30); 
setcookie("email", $email, time()+30); 
setcookie("showpass", $showpass, time()+30); 
setcookie("username", $username, time()+30); 
setcookie("group", $group, time()+30); 
}
if($emaildoesexist == "1") { // Check if email does exist
echo '<script language="JavaScript">
alert ("'.JText::_("EMAILEXISTS").'")
history.go(-1);
</script>';
} else {
	
if($usernameexists == "1") { // Check if username exists (and is configured not to be renamed)
echo '<script language="JavaScript">
alert ("'.JText::_("USERNAMEEXISTS").'")
history.go(-1);
</script>';
} else {
// When javascript is turned off there is no input field validation //
if($name == "" || $email == "" || $username == "" || $showpass == "") {
	
// Message when $name, $email, $username or $showpass are empty //
echo JText::_("SPAMBOT");

// Check if the groupid of the user which is added is not bigger or equal to the groupid of the user who is adding the new user.
} else if ($group >= $groupid) {
echo "You have tampered with the data from the form. User not created!";
// END - Check if the groupid of the user which is added is not bigger or equal to the groupid of the user who is adding the new user.

} else {	
if($groupid == "25" || $groupid == "24") { // if super administrator or administrator	
	
// Insert record into users
$sql = 'INSERT INTO ' . $table_prefix . 'users SET
`name`            = "' . $name . '",
`username`        = "' . $username .'",
`email`           = "' . $email .'",
`password`        = "' . $password .'",
`usertype`        = "' . $usertypename .'",
`block`           = "' . $block .'",
`sendEmail`       = "' . $sendmail . '",
`gid`             = "' . $usertype . '",
`registerDate`    = NOW(),
`lastvisitDate`   = "0000-00-00 00:00:00",
`activation`      = "1",
`params`          = ""';
mysql_query($sql);

// Get back user's ID
list($user_id) = mysql_fetch_row(mysql_query('SELECT LAST_INSERT_ID()'));

// Insert record into core_acl_aro
$sql ='INSERT INTO ' . $table_prefix . 'core_acl_aro SET
`section_value`   = "users",
`value`           = '. $user_id . ',
`name`            = "' . $name . '"
';
mysql_query($sql);

// Insert record into core_acl_groups_aro_map
$sql = 'INSERT INTO ' . $table_prefix . 'core_acl_groups_aro_map SET
`group_id`        = ' . $usertype . ',
`aro_id`          = LAST_INSERT_ID()
';
mysql_query($sql);

// Insert record into Community Builder //
if($operationmode == 1){
$sql ='INSERT INTO ' . $table_prefix . 'comprofiler SET
`id`              = "'. $user_id . '",
`user_id`         = "'. $user_id . '",
`firstname`       = "' . $firstname . '",
`lastname`              = "' . $lastname . '",
`hits`                  = "0",
`message_last_sent`     = "0000-00-00 00:00:00",
`message_number_sent`    = "0",
`approved`              = "1",
`confirmed`             = "1",
`lastupdatedate`       = "0000-00-00 00:00:00",
`banned`       = "0",
`acceptedterms`       = "1"
';
mysql_query($sql);	
} // End - CB mode or not

// Get userdata for export
$userdataexport = array (
  "username" => "$username",
  "email" => "$email",
  "name" => "$name",
  "password" => "$password",
  "id" => "$user_id",
  "group" => "$group",
);
// Fire the onAfterStoreUser trigger
JPluginHelper::importPlugin('user');
$dispatcher =& JDispatcher::getInstance();
$dispatcher->trigger('onAfterStoreUser', array($userdataexport, true, true, $this->getError()));
// Start executing plugins //
// Fire the onAfterStoreUserAuftoK2 trigger for K2 synchronization
$dispatcher->trigger('onAfterStoreUserAuftoK2', array($userdataexport, true, true, $this->getError()));
// End executing plugins //

// Flush
flush();
if($operationmode == 1){
	
echo '<br /><br /><strong>' . JText::_("ADDEDUSERTOJOOMLACB") . '!</strong><br><a href="index.php?option=com_comprofiler&task=userDetails&uid=' . $user_id . '"><strong>' . $username . '</strong></a> ' . JText::_("ADDEDUSERTOJOOMLACBTXT") . '';
}
if($operationmode == 0){
echo '<br /><br /><strong>' . JText::_("ADDEDUSERTOJOOMLA") . '</strong><br><strong>' . $username . '</strong> ' . JText::_("HASBEENADDEDTOJOOMLA") . '';
}

// Send notification to added user
if($notificationemail == "1"){
$config =& JFactory::getConfig();
// Prepare to send notification email
$fromname = $config->getValue( 'config.fromname' );
$from = $config->getValue( 'config.mailfrom' );
$recipient = $email;
$subject = "".JText::_("YOURDETAILFOR")." ".$_SERVER['HTTP_HOST']."";
$body   = "".JText::_("YOUHAVEBEENADDED")." http://".$_SERVER['HTTP_HOST']."\n\n".JText::_("THISMAILCONT")." http://".$_SERVER['HTTP_HOST']."\n\n".JText::_("USERNAME").": ".$username."\n\n".JText::_("PASSWORD").": ".$showpass."\n\n".JText::_("DONOTRESPOND")."
";
 
// Send notification now
JUtility::sendMail($from, $fromname, $recipient, $subject, $body, $mode=0, $cc=null, $bcc=null, $attachment, $replyto=null, $replytoname=null);
} 

// Send notification to admin
if($adminnotificationemail == "1"){
$config =& JFactory::getConfig();
// Prepare to send notification email //
$fromname = $config->getValue( 'config.fromname' );
$from = $config->getValue( 'config.mailfrom' );
$recipient = $from;
$subject = "A new user has been added to ".$_SERVER['HTTP_HOST']."";
$body   = "A new user has been added to ".$_SERVER['HTTP_HOST'].". This is a copy off the emailnotification that this user received:\n\n".JText::_("YOUHAVEBEENADDED")." http://".$_SERVER['HTTP_HOST']."\n\n".JText::_("THISMAILCONT")." http://".$_SERVER['HTTP_HOST']."\n\n".JText::_("USERNAME").": ".$username."\n\n".JText::_("PASSWORD").": xxx\n\n".JText::_("DONOTRESPOND")."
";
 
// Send notification now
JUtility::sendMail($from, $fromname, $recipient, $subject, $body, $mode=0, $cc=null, $bcc=null, $attachment, $replyto=null, $replytoname=null);
} 



} else {  // Rlse - super administrator or administrator
echo 'You do not have the permission to do this. You must be an administrator or superadministrator to add a user!';
}
 // End if super administrator or administrator
} // End security check
} // End double username check
} // End double email check
} else {
	
if($groupid == "25" || $groupid == "24") { // If super administrator or administrator
		
// Show upload form
?>
<script type="text/javascript">  
function validate_required(field,alerttxt)
{
with (field)
  {
  if (value==null||value=="")
    {
    alert(alerttxt);return false;
    }
  else
    {
    return true;
    }
  }
}
function validate_form(thisform)
{
with (thisform)
  {
<?php if( $namemode == "1" ): ?>
   if (validate_required(firstname,"<?php JText::printf( 'N0_FIRSTNAME') ?>")==false)
    {firstname.focus();return false;}
	
	 if (validate_required(lastname,"<?php JText::printf( 'N0_LASTNAME') ?>")==false)
    {lastname.focus();return false;}
	
<?php else: ?>
	
if (validate_required(name,"<?php echo JText::_("N0_NAME") ?>")==false)
{name.focus();return false;}
  
<?php endif; ?>
	
  <?php if( $genericemail !== "1" ): ?>
    if (validate_required(email,"<?php JText::printf( 'N0_EMAIL') ?>")==false)
    {email.focus();return false;}
	
	<?php endif; ?>
	
	
	
	
<?php if( $usernamemode == "1" ): ?>
		 if (validate_required(username,"<?php JText::printf( 'N0_USERNAME') ?>")==false)
    {username.focus();return false;}
	
<?php endif; ?>
	
<?php if( $passwordmode == "1" ): ?>
		 if (validate_required(password,"<?php JText::printf( 'N0_PASSWORD') ?>")==false)
    {password.focus();return false;}
	
<?php endif; ?>

<?php if( $usertypemode == "1" ): ?>
if (validate_required(group,"<?php JText::printf( 'NO_GROUP') ?>")==false) {	
group.focus();return false;}
<?php endif; ?>

	
  }
}
</script>
<?php 
// Getting data from cookies if used
if(isset($_COOKIE['firstname'])) {
$savedfirstname = $_COOKIE['firstname'];
}
if(isset($_COOKIE['lastname'])) {
$savedlastname = $_COOKIE['lastname'];
}
if(isset($_COOKIE['name'])) {
$savedname = $_COOKIE['name'];
}
if(isset($_COOKIE['email'])) {
$savedemail = $_COOKIE['email'];
}
if(isset($_COOKIE['username'])) {
$savedusername = $_COOKIE['username'];
}
if(isset($_COOKIE['group'])) {
$savedgroup = $_COOKIE['group'];
}
if(isset($_COOKIE['showpass'])) {
$savedshowpass = $_COOKIE['showpass'];
}
?>

<div>
  <h1>
    <?php JText::printf( 'ADD_USER') ?>
    :</h1>
  <hr />
  <form onsubmit="return validate_form(this);"  action="<?php echo JRoute::_('index.php?option=com_adduserfrontend&Itemid='.$itemid); ?>"  method="post" enctype="multipart/form-data">
    <input type="hidden" name="import" value="1" />
    <table cellpadding="4px">
      <?php if( $namemode == "1" ): ?>
      <tr>
        <td><?php JText::printf( 'FIRSTNAME') ?>
          : </td>
        <td><input type="text" name="firstname" value="<?php if(isset($savedfirstname)) { echo $savedfirstname; } ?>" /></td>
      </tr>
      <tr>
        <td><?php JText::printf( 'LASTNAME') ?>
          : </td>
        <td><input type="text" name="lastname" value="<?php if(isset($savedlastname)) { echo $savedlastname; } ?>" /></td>
      </tr>
      <?php else: ?>
      <tr>
        <td width="130"><?php JText::printf( 'NAME') ?>
          : </td>
        <td><input type="text" name="name" value="<?php if(isset($savedname)) { echo $savedname; } ?>" /></td>
      </tr>
      <?php endif; ?>
      <?php if( $genericemail !== "1" ): ?>
      <tr>
        <td><?php JText::printf( 'EMAIL') ?>
          : </td>
        <td><input type="text" name="email" value="<?php if(isset($savedemail)) { echo $savedemail; } ?>" /></td>
      </tr>
      <?php endif; ?>
      <?php if( $usernamemode == "1" ): ?>
      <tr>
        <td><?php JText::printf( 'USERNAME') ?>
          : </td>
        <td><input type="text" name="username" value="<?php if(isset($savedusername)) { echo $savedusername; } ?>" /></td>
      </tr>
      <?php endif; ?>
      <?php if( $passwordmode == "1" ): ?>
      <tr>
        <td><?php JText::printf( 'PASSWORD') ?>
          : </td>
        <td><input type="text" name="password" value="<?php if(isset($savedshowpass)) { echo $savedshowpass; } ?>" /></td>
      </tr>
      <?php endif; ?>
      <?php if( $usertypemode == "1" ): ?>
      <?php
      // Read from database all joomla's groups and print result in a selectbox
      // Select usergroups where gid is smaller then the users own gid 
      $query = "SELECT id,name FROM #__core_acl_aro_groups WHERE id < $groupid AND id != '17' order by id";	
      $db->setQuery($query); 
      $result = $db->loadRowList();
      ?>
      <tr>
        <td><?php JText::printf( 'GROUP') ?>
          : </td>
        <td><?php
		echo '<select name="group" type="text" value="'.$savedgroup.'">
		<option value=""> - - '.JText::_("SELECTGROUP").' - - </option>';
		foreach ($result as $line) {echo '<option value='.$line[0].'>'.$line[1].'</option>';}
		echo '</select>'; 
		?></td>
      </tr>
      <?php endif; ?>
      <tr>
        <td></td>
        <td><input type="submit" name="submit" value="<?php JText::printf( 'ADDNOW') ?>" /></td>
      </tr>
    </table>
  </form>
</div>
<?php
} else {
echo 'You must be an administrator or superadministrator to add a user!';	
}
}
?>
