<?php

// Login One! user plugin for Joomla 3.x
// (C)2011-2014 INNATO BV - www.innato.nl
// @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
// See file LICENSE
// **************************************************************************
// A plugin that prevents multiple log-ins by registered users
// Released under the GNU/GPLv3 License
// **************************************************************************

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

Please refer to the change log (changelog.php) of the Login One! authentication plug-in, which you will find in the installation package and in folder /plugins/authentication/loginone
