<?php

// $Id: Joomla! Login One! plugin. en.php  Version 1.0 Dec-2012
// Author INNATO BV - Rob Jakobs
// Copyright (C)2011-2014 INNATO BV. All rights reserved.
// @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
// See file LICENSE

if (!defined('OO_CANNOT_LOGIN_1')) DEFINE ('OO_CANNOT_LOGIN_1', 'You are not allowed to have multiple log-ins with the same user name. You can continue unregistered or sign in with a different user name.<br />If you have signed in at another work station and your session is still open, you should sign off there to unlock your account. Otherwise, you will need to wait&nbsp;');
if (!defined('OO_CANNOT_LOGIN_2')) DEFINE ('OO_CANNOT_LOGIN_2', ' before you retry to log in here.<br />If you see the waiting time increasing, the other work station is probably still active.');
if (!defined('OO_MINUTE')) DEFINE ('OO_MINUTE', '&nbsp;minute');
if (!defined('OO_MINUTES')) DEFINE ('OO_MINUTES', '&nbsp;minutes');
?>